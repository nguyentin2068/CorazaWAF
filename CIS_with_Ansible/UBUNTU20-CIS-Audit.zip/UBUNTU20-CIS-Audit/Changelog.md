# Changes to UbuntU20-CIS-Audit

## 1.0

### Based on CIS 1.1.0

many changes and improvement
audit not set to run from /opt (can be set via variable) run_audit script
Many changes to tests to ensure working more consistently

## 0.1 initial release

- Based on CIS 1.0
