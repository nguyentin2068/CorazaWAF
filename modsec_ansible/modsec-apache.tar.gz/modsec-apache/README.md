# Changed configure:

CentOS will be using Modsecurity package version 2.9.2, so some configuration will be changed

Comment line in modsecurity.conf:
- SecRequestBodyJsonDepthLimit 512
- SecArgumentsLimit 1000

Remove rule:
- REQUEST-922-MULTIPART-ATTACK.conf